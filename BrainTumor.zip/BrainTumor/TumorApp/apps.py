from django.apps import AppConfig


class TumorappConfig(AppConfig):
    name = 'TumorApp'
